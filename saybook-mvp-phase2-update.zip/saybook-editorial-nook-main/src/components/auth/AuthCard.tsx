import type { FormEvent, ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/brand/Logo";

interface Field { id: string; label: string; type: string; autoComplete: string }

/** Auth UI only. TODO(backend): replace onSubmit navigation with real authentication. */
export function AuthCard({ title, subtitle, fields, cta, footer }: { title: string; subtitle: string; fields: Field[]; cta: string; footer: ReactNode }) {
  const navigate = useNavigate();
  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    navigate({ to: "/dashboard" });
  };
  return (
    <div className="paper-grid flex min-h-screen flex-col items-center justify-center px-4 py-12">
      <div className="mb-8"><Logo /></div>
      <div className="w-full max-w-md rounded-2xl border bg-card p-8 shadow-lift">
        <h1 className="text-2xl font-semibold">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
        <form onSubmit={onSubmit} className="mt-6 space-y-4">
          {fields.map((f) => (
            <div key={f.id} className="grid gap-1.5">
              <Label htmlFor={f.id}>{f.label}</Label>
              <Input id={f.id} name={f.id} type={f.type} autoComplete={f.autoComplete} required minLength={f.type === "password" ? 8 : undefined} />
            </div>
          ))}
          <Button type="submit" className="w-full">{cta}</Button>
        </form>
        <p className="mt-4 rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">Preview mode: accounts aren't connected yet, so this opens the demo workspace.</p>
        <div className="mt-6 text-center text-sm text-muted-foreground">{footer}</div>
      </div>
    </div>
  );
}
