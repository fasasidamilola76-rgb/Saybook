import { Link } from "@tanstack/react-router";

export function Logo({ to = "/" }: { to?: "/" | "/dashboard" }) {
  return (
    <Link to={to} className="flex items-center gap-2.5">
      <span className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-ink text-ink-foreground">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden>
          <path d="M7 3c0 5 10 5 10 9s-10 4-10 9" />
          <path d="M17 3c0 5-10 5-10 9s10 4 10 9" opacity="0.55" />
        </svg>
      </span>
      <span className="font-serif text-lg font-semibold tracking-tight">SAY BOOK</span>
    </Link>
  );
}
