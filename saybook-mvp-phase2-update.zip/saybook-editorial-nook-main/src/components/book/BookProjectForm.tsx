import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import type { BookProjectInput } from "@/types/book";

type Field = { key: keyof BookProjectInput; label: string; help: string; placeholder: string; long?: boolean; required?: boolean };

const SECTIONS: { title: string; fields: Field[] }[] = [
  {
    title: "The book",
    fields: [
      { key: "title", label: "Book title", help: "A working title is fine.", placeholder: "e.g. Steady Hands", required: true },
      { key: "author", label: "Author name", help: "As it should appear on the outline.", placeholder: "e.g. Jordan Adeyemi" },
      { key: "topic", label: "Book topic", help: "The subject in a few words.", placeholder: "e.g. Leadership for first-time managers" },
    ],
  },
  {
    title: "The reader",
    fields: [
      { key: "audience", label: "Target audience", help: "Who is this book written for?", placeholder: "e.g. Engineers recently promoted to team lead" },
      { key: "problem", label: "Main problem the book addresses", help: "The external problem your reader is facing.", placeholder: "e.g. New managers are left to improvise people leadership.", long: true },
      { key: "transformation", label: "Desired reader transformation", help: "Who will the reader become by the last page?", placeholder: "e.g. From anxious expert to calm, deliberate leader.", long: true },
    ],
  },
  {
    title: "Your Book Wish",
    fields: [
      { key: "bookWish", label: "Book Wish", help: "Your central book idea or intended outcome, in one or two sentences. It anchors the whole Double Helix Map.", placeholder: "e.g. I want new managers to finish this book knowing leadership is a learnable practice.", long: true, required: true },
      { key: "context", label: "Additional context", help: "Optional — experience, sources, or constraints worth remembering.", placeholder: "e.g. Draws on ten years of coaching operations teams.", long: true },
    ],
  },
];

export const EMPTY_INPUT: BookProjectInput = { title: "", author: "", topic: "", audience: "", problem: "", transformation: "", bookWish: "", context: "" };

export function BookProjectForm({ onSaveDraft, onContinue, initialValues, editing = false }: { onSaveDraft: (v: BookProjectInput) => void; onContinue: (v: BookProjectInput) => void; initialValues?: BookProjectInput; editing?: boolean }) {
  const [values, setValues] = useState<BookProjectInput>(initialValues ?? EMPTY_INPUT);
  const [touched, setTouched] = useState(false);
  const missing = !values.title.trim() || !values.bookWish.trim();

  const submit = (fn: (v: BookProjectInput) => void) => {
    setTouched(true);
    if (!missing) fn(values);
  };

  return (
    <form className="space-y-8" onSubmit={(e) => { e.preventDefault(); submit(onContinue); }}>
      {SECTIONS.map((section, si) => (
        <fieldset key={section.title} className="border-b pb-6">
          <legend className="sr-only">{section.title}</legend>
          <div className="mb-5 flex items-center gap-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-accent text-sm font-semibold text-accent-foreground">{si + 1}</span>
            <h2 className="text-xl font-semibold">{section.title}</h2>
          </div>
          <div className="grid gap-5">
            {section.fields.map((f) => {
              const Comp = f.long ? Textarea : Input;
              const invalid = touched && f.required && !values[f.key].trim();
              return (
                <div key={f.key} className="grid gap-1.5">
                  <Label htmlFor={f.key}>{f.label}{f.required && <span className="text-destructive"> *</span>}</Label>
                  <p className="text-sm text-muted-foreground">{f.help}</p>
                  <Comp
                    id={f.key}
                    value={values[f.key]}
                    placeholder={f.placeholder}
                    aria-invalid={invalid}
                    onChange={(e) => setValues({ ...values, [f.key]: e.target.value })}
                  />
                  {invalid && <p className="text-sm text-destructive">This field is required.</p>}
                </div>
              );
            })}
          </div>
        </fieldset>
      ))}
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        {!editing && <Button type="button" variant="outline" onClick={() => submit(onSaveDraft)}>Save Draft</Button>}
        <Button type="submit">{editing ? "Save book details" : "Continue to DHM Setup"}</Button>
      </div>
    </form>
  );
}
