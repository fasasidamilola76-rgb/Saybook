import { arcStyles, ArcBadge } from "@/components/book/badges";
import { SyntaxChips } from "@/components/book/SyntaxChips";
import { cn } from "@/lib/utils";
import type { ArcStage, SayPoint } from "@/types/book";

const rows: { n: number; arc: ArcStage; sot: string; syntax: SayPoint[]; ga: string }[] = [
  { n: 1, arc: "awareness", sot: "Most managers are promoted for work they will no longer do.", syntax: [["S", "Y", "A"], ["A", "S", "A"], ["Y", "A", "A"]], ga: "Name the job you now have." },
  { n: 2, arc: "resolution", sot: "A weekly rhythm turns leadership into practice.", syntax: [["Y", "S", "A"], ["S", "A", "A"]], ga: "Protect one-to-ones first." },
  { n: 3, arc: "cta", sot: "Leading becomes part of who you are.", syntax: [["A", "Y", "A"]], ga: "Teach the rhythm to your team." },
];

/** Static illustration of the Double Helix Map for marketing pages. Sample content. */
export function HelixPreview({ className }: { className?: string }) {
  return (
    <div className={cn("rounded-2xl border bg-card p-4 shadow-lift sm:p-6", className)}>
      <div className="mb-4 flex items-center justify-between">
        <p className="eyebrow">Double Helix Map · Sample</p>
        <span className="flex gap-1">
          <span className="h-2 w-2 rounded-full bg-border" />
          <span className="h-2 w-2 rounded-full bg-border" />
          <span className="h-2 w-2 rounded-full bg-border" />
        </span>
      </div>
      <div className="hidden grid-cols-[1fr_1fr_1fr] gap-3 px-3 pb-2 sm:grid">
        <p className="eyebrow">Grand Narrative</p>
        <p className="eyebrow">Development</p>
        <p className="eyebrow">Grand Advice</p>
      </div>
      <div className="space-y-3">
        {rows.map((r) => (
          <div key={r.n} className={cn("relative rounded-xl border-l-4 bg-surface p-3", arcStyles[r.arc].border)}>
            <div className="mb-2 flex items-center gap-2">
              <span className="font-serif text-sm font-semibold">Ch. {r.n}</span>
              <ArcBadge stage={r.arc} />
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <p className="font-serif text-sm leading-snug">{r.sot}</p>
              <SyntaxChips syntax={r.syntax} />
              <p className="text-sm leading-snug text-muted-foreground">{r.ga}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
