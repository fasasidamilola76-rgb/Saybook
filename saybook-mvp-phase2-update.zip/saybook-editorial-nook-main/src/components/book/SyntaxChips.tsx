import { cn } from "@/lib/utils";
import type { SayPoint, SayUnit } from "@/types/book";

const unitStyle: Record<SayUnit, string> = {
  S: "bg-arc-a-soft text-arc-a",
  Y: "bg-arc-r-soft text-arc-r",
  A: "bg-arc-c-soft text-arc-c",
};

export function SayUnitChip({ unit, className }: { unit: SayUnit; className?: string }) {
  return (
    <span className={cn("inline-flex h-6 w-6 items-center justify-center rounded-md font-mono text-xs font-bold", unitStyle[unit], className)}>
      {unit}
    </span>
  );
}

export function SyntaxChips({ syntax, empty = "No syntax yet" }: { syntax: SayPoint[]; empty?: string }) {
  if (!syntax.length) return <span className="text-sm italic text-muted-foreground">{empty}</span>;
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {syntax.map((point, i) => (
        <span key={i} className="flex items-center gap-1.5">
          {i > 0 && <span className="text-xs text-muted-foreground">+</span>}
          <span className="flex gap-0.5 rounded-lg border bg-card p-0.5">
            {point.map((u, j) => (
              <SayUnitChip key={j} unit={u} />
            ))}
          </span>
        </span>
      ))}
    </div>
  );
}
