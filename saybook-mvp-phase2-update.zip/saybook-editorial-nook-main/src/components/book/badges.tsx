import { cn } from "@/lib/utils";
import { ARC_INFO } from "@/lib/book-config";
import type { ArcStage, ProjectStatus } from "@/types/book";
import type { DiagnosticStatus } from "@/lib/diagnostics";

export const arcStyles: Record<ArcStage, { text: string; bg: string; border: string; dot: string }> = {
  awareness: { text: "text-arc-a", bg: "bg-arc-a-soft", border: "border-arc-a", dot: "bg-arc-a" },
  resolution: { text: "text-arc-r", bg: "bg-arc-r-soft", border: "border-arc-r", dot: "bg-arc-r" },
  cta: { text: "text-arc-c", bg: "bg-arc-c-soft", border: "border-arc-c", dot: "bg-arc-c" },
};

export function ArcBadge({ stage, short }: { stage: ArcStage; short?: boolean }) {
  const s = arcStyles[stage];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold", s.bg, s.text)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
      {short ? ARC_INFO[stage].letter : ARC_INFO[stage].name}
    </span>
  );
}

export function StatusBadge({ status }: { status: ProjectStatus }) {
  return (
    <span
      className={cn(
        "inline-flex rounded-full border px-2.5 py-0.5 text-xs font-medium",
        status === "completed" ? "border-success/30 bg-success/10 text-success" : "border-border bg-muted text-muted-foreground",
      )}
    >
      {status === "completed" ? "Completed" : "Draft"}
    </span>
  );
}

const diagLabel: Record<DiagnosticStatus, string> = {
  complete: "Complete",
  attention: "Needs Attention",
  incomplete: "Incomplete",
};

export function DiagnosticBadge({ status }: { status: DiagnosticStatus }) {
  return (
    <span
      className={cn(
        "inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold",
        status === "complete" && "bg-success/10 text-success",
        status === "attention" && "bg-warning/15 text-warning",
        status === "incomplete" && "bg-destructive/10 text-destructive",
      )}
    >
      {diagLabel[status]}
    </span>
  );
}

export function SampleBadge() {
  return (
    <span className="inline-flex rounded-md border border-dashed border-primary/40 bg-accent px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-accent-foreground">
      Sample
    </span>
  );
}
