import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ARC_INFO, ARC_ORDER, projectArcSequence } from "@/lib/book-config";
import { setProjectArc } from "@/services/project-store";
import type { BookProject } from "@/types/book";

export function ArcStructureEditor({ project }: { project: BookProject }) {
  const sequence = projectArcSequence(project);
  const [counts, setCounts] = useState(() => ARC_ORDER.map((stage) => sequence.filter((value) => value === stage).length));
  const total = counts.reduce((sum, count) => sum + count, 0);
  const valid = total === 9 && counts.every((count) => Number.isInteger(count) && count >= 0 && count <= 9);
  return (
    <fieldset className="mt-6 space-y-4 border-t pt-6">
      <legend className="font-serif text-xl font-semibold">Custom ARC structure</legend>
      <div className="grid gap-4 sm:grid-cols-3">
        {ARC_ORDER.map((stage, index) => (
          <div key={stage} className="grid gap-2">
            <Label htmlFor={`arc-${stage}`}>{ARC_INFO[stage].name}</Label>
            <Input id={`arc-${stage}`} type="number" min={0} max={9} step={1} value={counts[index]} onChange={(event) => setCounts(counts.map((count, i) => i === index ? Number(event.target.value) : count))} />
          </div>
        ))}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className={valid ? "text-sm text-muted-foreground" : "text-sm text-destructive"} role="status">{total} of 9 chapters allocated</p>
        <Button disabled={!valid} variant="outline" onClick={() => setProjectArc(project.id, ARC_ORDER.flatMap((stage, index) => Array.from({ length: counts[index] ?? 0 }, () => stage)))}>Apply ARC structure</Button>
      </div>
    </fieldset>
  );
}