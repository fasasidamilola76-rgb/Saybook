import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { PLANS } from "@/lib/book-config";
import type { PlanId } from "@/types/book";
import { Button } from "@/components/ui/button";

export function PlanCard({ plan, selected, onSelect }: { plan: PlanId; selected?: boolean; onSelect?: () => void }) {
  const p = PLANS[plan];
  const features = [
    `${p.chapters} chapters`,
    `ARC ${p.arcLabel}`,
    `${p.matrix.rows}×${p.matrix.cols} matrix`,
    `${p.revisedWishes} revised Wish${p.revisedWishes > 1 ? "es" : ""}`,
    ...p.extras,
  ];
  return (
    <div
      className={cn(
        "flex h-full flex-col rounded-xl border bg-card p-6 text-left shadow-card transition-colors",
        onSelect && "hover:border-primary/50",
        selected && "border-primary ring-2 ring-primary/20",
        plan === "founding" && !selected && "bg-surface",
      )}
    >
      <div className="flex items-center justify-between">
        <p className="eyebrow">{p.name}</p>
        {selected && <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">Selected</span>}
      </div>
      <p className="mt-3 font-serif text-4xl font-semibold">${p.price}</p>
      <ul className="mt-5 space-y-2.5 text-sm">
        {features.map((f) => (
          <li key={f} className="flex gap-2">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            {f}
          </li>
        ))}
      </ul>
      {onSelect && <Button variant={selected ? "default" : "outline"} aria-pressed={selected} onClick={onSelect} className="mt-6 w-full">{selected ? `${p.name} selected` : `Select ${p.name}`}</Button>}
    </div>
  );
}
