import { Link } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { SampleBadge, StatusBadge } from "@/components/book/badges";
import { formatDate, isChapterFilled, PLANS, projectArcLabel } from "@/lib/book-config";
import { deleteProject } from "@/services/project-store";
import type { BookProject } from "@/types/book";

export function ProjectCard({ project }: { project: BookProject }) {
  const filled = project.chapters.filter(isChapterFilled).length;
  const pct = Math.round((filled / project.chapters.length) * 100);
  return (
    <div className="flex flex-col rounded-xl border bg-card p-5 shadow-card">
      <div className="mb-3 flex items-center gap-2">
        <StatusBadge status={project.status} />
        {project.isSample && <SampleBadge />}
      </div>
      <h3 className="text-xl font-semibold">{project.title || "Untitled book"}</h3>
      <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{project.bookWish || "No Book Wish yet."}</p>
      <div className="mt-4 space-y-1.5">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{PLANS[project.plan].name} · ARC {projectArcLabel(project)}</span>
          <span>{filled}/{project.chapters.length} chapters</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-muted">
          <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
        </div>
      </div>
      <div className="mt-5 flex items-center justify-between border-t pt-4">
        <span className="text-xs text-muted-foreground">Edited {formatDate(project.updatedAt)}</span>
        <div className="flex gap-1">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Delete project">
                <Trash2 className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete “{project.title || "Untitled book"}”?</AlertDialogTitle>
                <AlertDialogDescription>This removes the project and its Double Helix Map.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => deleteProject(project.id)}>Delete</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <Button asChild size="sm">
            <Link to="/projects/$projectId/dhm" params={{ projectId: project.id }}>Continue Editing</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
