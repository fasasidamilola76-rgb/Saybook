import { useState } from "react";
import { CheckCircle2, ChevronDown, Circle, StickyNote } from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { arcStyles, ArcBadge } from "@/components/book/badges";
import { SyntaxChips } from "@/components/book/SyntaxChips";
import type { Chapter } from "@/types/book";

interface Props {
  chapter: Chapter;
  onChange: (patch: Partial<Chapter>) => void;
  onEditSyntax: () => void;
}

const fieldCls = "min-h-24 resize-none border-transparent bg-transparent px-2 shadow-none focus-visible:border-input focus-visible:bg-card";

/** One chapter of the helix: three strands side by side on desktop, stacked on mobile. */
export function ChapterRow({ chapter, onChange, onEditSyntax }: Props) {
  const [open, setOpen] = useState(true);
  const s = arcStyles[chapter.arc];

  return (
    <article className={cn("rounded-xl border border-l-4 bg-card shadow-card", s.border)}>
      <header className="flex items-center gap-3 border-b px-4 py-3">
        <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-full font-serif text-sm font-semibold", s.bg, s.text)}>
          {chapter.number}
        </span>
        <Input
          value={chapter.title}
          onChange={(e) => onChange({ title: e.target.value })}
          placeholder="Chapter title"
          aria-label={`Chapter ${chapter.number} title`}
          className="h-9 flex-1 border-transparent bg-transparent font-serif text-base font-semibold shadow-none focus-visible:border-input"
        />
        <span className="hidden sm:inline-flex"><ArcBadge stage={chapter.arc} /></span>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onChange({ complete: !chapter.complete })}
          className={cn("gap-1.5", chapter.complete ? "text-success" : "text-muted-foreground")}
          aria-pressed={chapter.complete}
          aria-label={chapter.complete ? "Mark chapter incomplete" : "Mark chapter complete"}
        >
          {chapter.complete ? <CheckCircle2 className="h-4 w-4" /> : <Circle className="h-4 w-4" />}
          <span className="hidden md:inline">{chapter.complete ? "Complete" : "Mark complete"}</span>
        </Button>
        <Button variant="ghost" size="icon" onClick={() => setOpen(!open)} aria-expanded={open} aria-label={open ? "Collapse chapter" : "Expand chapter"}>
          <ChevronDown className={cn("h-4 w-4 transition-transform", !open && "-rotate-90")} />
        </Button>
      </header>

      {open && (
        <>
          <div className="grid divide-y lg:grid-cols-3 lg:divide-x lg:divide-y-0">
            <section className="p-3">
              <p className="eyebrow mb-1 px-2 lg:hidden">Story of Thesis</p>
              <Textarea
                value={chapter.storyOfThesis}
                onChange={(e) => onChange({ storyOfThesis: e.target.value })}
                placeholder="One sentence that advances the book's argument…"
                aria-label="Story of Thesis"
                className={cn(fieldCls, "font-serif text-[15px] leading-relaxed")}
              />
            </section>
            <section className="space-y-2 p-3">
              <p className="eyebrow px-2 lg:hidden">Development</p>
              <Button type="button" variant="ghost" onClick={onEditSyntax} aria-label={`Edit chapter ${chapter.number} syntax`} className="h-auto w-full justify-start whitespace-normal px-2 py-1.5 text-left">
                <SyntaxChips syntax={chapter.syntax} empty="Arrange SAY syntax →" />
              </Button>
              <Textarea
                value={chapter.development}
                onChange={(e) => onChange({ development: e.target.value })}
                placeholder="Development notes for these SAY points…"
                aria-label="Development notes"
                className={cn(fieldCls, "min-h-16 text-sm")}
              />
            </section>
            <section className="p-3">
              <p className="eyebrow mb-1 px-2 lg:hidden">Grand Advice</p>
              <Textarea
                value={chapter.grandAdvice}
                onChange={(e) => onChange({ grandAdvice: e.target.value })}
                placeholder="The main instruction this chapter leaves the reader with…"
                aria-label="Grand Advice"
                className={cn(fieldCls, "text-sm")}
              />
            </section>
          </div>
          <footer className="flex items-start gap-2 border-t bg-surface/60 px-4 py-2">
            <StickyNote className="mt-2 h-4 w-4 shrink-0 text-muted-foreground" />
            <Textarea
              value={chapter.notes}
              onChange={(e) => onChange({ notes: e.target.value })}
              placeholder="Add a note…"
              aria-label="Chapter notes"
              className="min-h-9 resize-none border-transparent bg-transparent px-1 text-sm shadow-none focus-visible:border-input focus-visible:bg-card"
            />
          </footer>
        </>
      )}
    </article>
  );
}
