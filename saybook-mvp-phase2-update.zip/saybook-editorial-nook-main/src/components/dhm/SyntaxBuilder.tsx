import { ArrowDown, ArrowUp, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SayUnitChip, SyntaxChips } from "@/components/book/SyntaxChips";
import { formatSyntax, SAY_INFO, SAY_MODULE_NOTE } from "@/lib/book-config";
import type { SayPoint, SayUnit } from "@/types/book";

const UNITS: SayUnit[] = ["S", "Y", "A"];
const EXAMPLES: SayPoint[] = [["S", "Y", "A"], ["A", "S", "A"], ["Y", "A", "A"]];

const expand = (p: SayPoint) => p.map((u) => SAY_INFO[u]).join(" → ");

export function SyntaxReference() {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-4">
        {UNITS.map((u) => (
          <span key={u} className="flex items-center gap-2 text-sm">
            <SayUnitChip unit={u} /> {SAY_INFO[u]}
          </span>
        ))}
      </div>
      <ul className="space-y-2">
        {EXAMPLES.map((e) => (
          <li key={e.join("")} className="flex items-center gap-3 text-sm">
            <span className="w-10 font-mono font-bold">{e.join("")}</span>
            <span className="text-muted-foreground">= {expand(e)}</span>
          </li>
        ))}
      </ul>
      <div className="rounded-lg bg-surface p-3 text-sm">
        <p className="eyebrow mb-1">Example first-chapter syntax</p>
        <p className="font-mono font-bold">SYA + ASA + YAA</p>
      </div>
      <p className="text-sm italic text-muted-foreground">{SAY_MODULE_NOTE}</p>
    </div>
  );
}

/** Build a chapter's sequence of SAY points (each a 3-unit pattern). */
export function SyntaxBuilder({ value, onChange }: { value: SayPoint[]; onChange: (v: SayPoint[]) => void }) {
  const setPoint = (i: number, p: SayPoint) => onChange(value.map((x, j) => (j === i ? p : x)));
  const move = (i: number, d: -1 | 1) => {
    const next = [...value];
    const a = next[i], b = next[i + d];
    if (!a || !b) return;
    next[i] = b;
    next[i + d] = a;
    onChange(next);
  };

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        {value.length === 0 && <p className="text-sm text-muted-foreground">No SAY points yet. Add one below or start from an example.</p>}
        {value.map((point, i) => (
          <div key={i} className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-3">
            <span className="w-14 text-xs font-semibold text-muted-foreground">Point {i + 1}</span>
            <div className="flex gap-1.5">
              {point.map((u, pos) => (
                <div key={pos} className="flex flex-col gap-0.5 rounded-md border p-0.5">
                  {UNITS.map((opt) => (
                    <Button
                      variant="ghost"
                      size="icon"
                      key={opt}
                      type="button"
                      onClick={() => setPoint(i, point.map((x, k) => (k === pos ? opt : x)))}
                      aria-label={`Position ${pos + 1}: ${SAY_INFO[opt]}`}
                      aria-pressed={u === opt}
                      className={u === opt ? "h-8 w-8" : "h-8 w-8 opacity-30 hover:opacity-70"}
                    >
                      <SayUnitChip unit={opt} />
                    </Button>
                  ))}
                </div>
              ))}
            </div>
            <span className="flex-1 text-sm text-muted-foreground">{expand(point)}</span>
            <div className="flex">
              <Button variant="ghost" size="icon" disabled={i === 0} onClick={() => move(i, -1)} aria-label="Move up"><ArrowUp className="h-4 w-4" /></Button>
              <Button variant="ghost" size="icon" disabled={i === value.length - 1} onClick={() => move(i, 1)} aria-label="Move down"><ArrowDown className="h-4 w-4" /></Button>
              <Button variant="ghost" size="icon" onClick={() => onChange(value.filter((_, j) => j !== i))} aria-label="Remove point"><X className="h-4 w-4" /></Button>
            </div>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" size="sm" onClick={() => onChange([...value, ["S", "Y", "A"]])}>
          <Plus className="h-4 w-4" /> Add SAY point
        </Button>
        {EXAMPLES.map((e) => (
          <Button key={e.join("")} variant="secondary" size="sm" onClick={() => onChange([...value, [...e]])}>
            + {e.join("")}
          </Button>
        ))}
      </div>
      <div className="rounded-lg bg-surface p-4">
        <p className="eyebrow mb-2">Preview</p>
        <SyntaxChips syntax={value} />
        {value.length > 0 && <p className="mt-2 font-mono text-sm font-bold">{formatSyntax(value)}</p>}
        <p className="mt-2 text-xs text-muted-foreground">{SAY_MODULE_NOTE}</p>
      </div>
    </div>
  );
}
