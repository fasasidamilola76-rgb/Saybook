import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { ARC_INFO } from "@/lib/book-config";
import { arcStyles } from "@/components/book/badges";
import type { ArcStage } from "@/types/book";

export function ArcSection({ stage, count, children }: { stage: ArcStage; count: number; children: ReactNode }) {
  const info = ARC_INFO[stage];
  const s = arcStyles[stage];
  return (
    <section className="space-y-3">
      <div className={cn("flex items-center gap-4 rounded-xl px-4 py-3", s.bg)}>
        <span className={cn("font-serif text-3xl font-semibold", s.text)}>{info.letter}</span>
        <div className="flex-1">
          <h2 className={cn("text-lg font-semibold", s.text)}>{info.name}</h2>
          <p className="text-sm text-muted-foreground">{info.focus}</p>
        </div>
        <span className="text-sm text-muted-foreground">{count} chapter{count !== 1 && "s"}</span>
      </div>
      {children}
    </section>
  );
}

export function ArcStageCard({ stage }: { stage: ArcStage }) {
  const info = ARC_INFO[stage];
  const s = arcStyles[stage];
  return (
    <div className={cn("rounded-xl border-t-4 bg-card p-6 shadow-card", s.border)}>
      <span className={cn("font-serif text-5xl font-semibold", s.text)}>{info.letter}</span>
      <h3 className="mt-3 text-xl font-semibold uppercase tracking-wide">{info.name}</h3>
      <p className="mt-2 text-muted-foreground">{info.focus}</p>
    </div>
  );
}
