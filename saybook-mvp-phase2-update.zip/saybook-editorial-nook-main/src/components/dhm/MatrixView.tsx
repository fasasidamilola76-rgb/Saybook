import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { Matrix } from "@/types/book";

/** Editable matrix. Labels are neutral and user-defined — cell meaning is not prescribed. */
export function MatrixView({ matrix, onChange }: { matrix: Matrix; onChange: (m: Matrix) => void }) {
  const setRow = (r: number, v: string) => onChange({ ...matrix, rowLabels: matrix.rowLabels.map((x, i) => (i === r ? v : x)) });
  const setCol = (c: number, v: string) => onChange({ ...matrix, colLabels: matrix.colLabels.map((x, i) => (i === c ? v : x)) });
  const setCell = (r: number, c: number, v: string) =>
    onChange({ ...matrix, cells: matrix.cells.map((row, i) => (i === r ? row.map((x, j) => (j === c ? v : x)) : row)) });

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
        {matrix.rowLabels.length}×{matrix.colLabels.length} matrix. Rename rows and columns to suit your book.
      </p>
      <div className="overflow-x-auto rounded-xl border bg-card shadow-card">
        <table className="w-full min-w-[640px] border-collapse">
          <thead>
            <tr>
              <th className="w-40 border-b bg-surface p-2" />
              {matrix.colLabels.map((l, c) => (
                <th key={c} className="border-b border-l bg-surface p-2">
                  <Input value={l} onChange={(e) => setCol(c, e.target.value)} aria-label={`Column ${c + 1} label`} className="h-8 border-transparent bg-transparent text-center font-semibold shadow-none" />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {matrix.cells.map((row, r) => (
              <tr key={r}>
                <th className="border-b bg-surface p-2">
                  <Input value={matrix.rowLabels[r]} onChange={(e) => setRow(r, e.target.value)} aria-label={`Row ${r + 1} label`} className="h-8 border-transparent bg-transparent font-semibold shadow-none" />
                </th>
                {row.map((cell, c) => (
                  <td key={c} className="border-b border-l p-1 align-top">
                    <Textarea value={cell} onChange={(e) => setCell(r, c, e.target.value)} aria-label={`Cell ${r + 1}, ${c + 1}`} placeholder="—" className="min-h-20 resize-none border-transparent bg-transparent text-sm shadow-none focus-visible:border-input" />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
