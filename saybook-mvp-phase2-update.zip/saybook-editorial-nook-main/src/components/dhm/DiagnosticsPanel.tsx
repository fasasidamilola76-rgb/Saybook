import { Cpu, UserCheck } from "lucide-react";
import { DiagnosticBadge } from "@/components/book/badges";
import { runDiagnostics } from "@/lib/diagnostics";
import type { BookProject } from "@/types/book";

export function DiagnosticsPanel({ project }: { project: BookProject }) {
  const results = runDiagnostics(project);
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-6 rounded-xl bg-surface p-4 text-sm">
        <span className="flex items-center gap-2"><Cpu className="h-4 w-4 text-primary" /> <b>Automated check</b> — structural count of your fields</span>
        <span className="flex items-center gap-2"><UserCheck className="h-4 w-4 text-arc-a" /> <b>Needs human review</b> — meaning and flow must be judged by you</span>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {results.map((r) => (
          <div key={r.id} className="rounded-xl border bg-card p-5 shadow-card">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="mb-1 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                  {r.kind === "automated" ? <><Cpu className="h-3.5 w-3.5" /> Automated check</> : <><UserCheck className="h-3.5 w-3.5" /> Suggestion · human review</>}
                </p>
                <h3 className="text-lg font-semibold">{r.title}</h3>
              </div>
              <DiagnosticBadge status={r.status} />
            </div>
            <p className="mt-2 text-sm text-muted-foreground">{r.summary}</p>
            {r.details.length > 0 && (
              <ul className="mt-3 space-y-1 border-t pt-3 text-sm">
                {r.details.map((d) => <li key={d}>· {d}</li>)}
              </ul>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
