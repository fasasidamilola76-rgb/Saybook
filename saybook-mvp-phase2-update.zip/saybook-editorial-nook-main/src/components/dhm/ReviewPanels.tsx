import { useState } from "react";
import { AlertCircle, Check, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArcBadge } from "@/components/book/badges";
import { cn } from "@/lib/utils";
import type { Chapter } from "@/types/book";

type OnChange = (chapterId: string, patch: Partial<Chapter>) => void;

function EditableSentence({ value, onSave, placeholder }: { value: string; onSave: (v: string) => void; placeholder: string }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  if (editing)
    return (
      <div className="space-y-2">
        <Textarea autoFocus value={draft} onChange={(e) => setDraft(e.target.value)} placeholder={placeholder} />
        <div className="flex gap-2">
          <Button size="sm" onClick={() => { onSave(draft); setEditing(false); }}>Save</Button>
          <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>Cancel</Button>
        </div>
      </div>
    );
  return (
    <div className="flex items-start gap-2">
      {value ? (
        <p className="flex-1 font-serif text-lg leading-relaxed">{value}</p>
      ) : (
        <p className="flex flex-1 items-center gap-2 text-sm font-medium text-destructive">
          <AlertCircle className="h-4 w-4" /> Missing sentence
        </p>
      )}
      <Button variant="ghost" size="icon" onClick={() => { setDraft(value); setEditing(true); }} aria-label="Edit">
        <Pencil className="h-4 w-4" />
      </Button>
    </div>
  );
}

export function ThesisReview({ chapters, onChange }: { chapters: Chapter[]; onChange: OnChange }) {
  const continuous = chapters.map((c) => c.storyOfThesis.trim()).filter(Boolean).join(" ");
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
      <ol className="space-y-3">
        {chapters.map((c) => (
          <li key={c.id} className="rounded-xl border bg-card p-4 shadow-card">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <span className="text-sm font-semibold">Chapter {c.number}</span>
              <ArcBadge stage={c.arc} />
              <span className="flex-1 truncate text-sm text-muted-foreground">{c.title}</span>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onChange(c.id, { thesisReview: c.thesisReview === "reviewed" ? "unreviewed" : "reviewed" })}
                className={cn("gap-1", c.thesisReview === "reviewed" ? "text-success" : "text-muted-foreground")}
              >
                <Check className="h-4 w-4" /> {c.thesisReview === "reviewed" ? "Reviewed" : "Mark reviewed"}
              </Button>
            </div>
            <EditableSentence value={c.storyOfThesis} placeholder="Story of Thesis sentence" onSave={(v) => onChange(c.id, { storyOfThesis: v, thesisReview: "unreviewed" })} />
          </li>
        ))}
      </ol>
      <aside className="h-fit rounded-xl bg-ink p-6 text-ink-foreground lg:sticky lg:top-20">
        <p className="eyebrow mb-3 text-ink-foreground/60">Read as one argument</p>
        <p className="font-serif text-lg leading-relaxed">{continuous || "Thesis sentences will appear here in chapter order."}</p>
      </aside>
    </div>
  );
}

export function AdviceReview({ chapters, onChange }: { chapters: Chapter[]; onChange: OnChange }) {
  return (
    <div className="space-y-2">
      <p className="mb-4 max-w-2xl text-muted-foreground">
        Read each Grand Advice statement in order to see how the instructional argument develops across the book.
      </p>
      <ol className="relative space-y-3 border-l-2 border-border pl-6">
        {chapters.map((c) => (
          <li key={c.id} className="relative rounded-xl border bg-card p-4 shadow-card">
            <span className="absolute -left-[33px] top-5 flex h-4 w-4 items-center justify-center rounded-full border-2 border-background bg-primary" />
            <div className="mb-2 flex items-center gap-2">
              <span className="text-sm font-semibold">Chapter {c.number}</span>
              <ArcBadge stage={c.arc} />
              <span className="truncate text-sm text-muted-foreground">{c.title}</span>
            </div>
            <EditableSentence value={c.grandAdvice} placeholder="Grand Advice statement" onSave={(v) => onChange(c.id, { grandAdvice: v })} />
          </li>
        ))}
      </ol>
    </div>
  );
}
