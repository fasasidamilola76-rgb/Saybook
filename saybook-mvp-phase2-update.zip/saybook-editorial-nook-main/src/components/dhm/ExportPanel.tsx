import { FileDown } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ARC_INFO, ARC_ORDER, formatSyntax, projectArcSequence, projectArcLabel } from "@/lib/book-config";
import { exportDhmPdf } from "@/services/export-service";
import type { BookProject } from "@/types/book";

export function ExportPanel({ project }: { project: BookProject }) {
  const sequence = projectArcSequence(project);
  const handleExport = async () => {
    const res = await exportDhmPdf(project);
    if (!res.ok) toast.error("Could not open PDF export", { description: res.reason });
    else toast.success("Print-ready book architecture opened", { description: "In the print dialog, choose Save as PDF to download your document." });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
      <aside className="h-fit space-y-4 rounded-xl border bg-card p-5 shadow-card">
        <h3 className="text-lg font-semibold">Export</h3>
        <p className="text-sm text-muted-foreground">A print-ready blueprint containing your saved book architecture and matrix.</p>
        <Button className="w-full" onClick={handleExport}><FileDown className="h-4 w-4" /> Export DHM as PDF</Button>
        <p className="text-xs text-muted-foreground">Your browser opens the print dialog. Choose “Save as PDF” as the destination to download the PDF.</p>
      </aside>

      <div className="rounded-xl border bg-card p-8 shadow-lift sm:p-12">
        <header className="border-b pb-6">
          <p className="eyebrow">Double Helix Map</p>
          <h2 className="mt-2 text-3xl font-semibold">{project.title || "Untitled book"}</h2>
          <p className="mt-1 text-muted-foreground">{project.author}</p>
          <div className="mt-5">
            <p className="eyebrow mb-1">Book Wish</p>
            <p className="font-serif italic">{project.bookWish || "—"}</p>
          </div>
          <p className="mt-4 text-sm">
            <b>ARC structure:</b> {projectArcLabel(project)} — {ARC_ORDER.map((s) => `${sequence.filter((stage) => stage === s).length} ${ARC_INFO[s].name}`).join(", ")}
          </p>
        </header>
        <div className="overflow-x-auto"><table className="mt-6 w-full min-w-[560px] text-left text-sm">
          <thead>
            <tr className="border-b text-xs uppercase tracking-wider text-muted-foreground">
              <th className="py-2 pr-3">Ch.</th>
              <th className="py-2 pr-3">Story of Thesis</th>
              <th className="py-2 pr-3">Development</th>
              <th className="py-2">Grand Advice</th>
            </tr>
          </thead>
          <tbody>
            {project.chapters.map((c) => (
              <tr key={c.id} className="border-b align-top">
                <td className="py-3 pr-3">
                  <b>{c.number}</b> <span className="text-muted-foreground">{ARC_INFO[c.arc].letter}</span>
                  <div className="font-serif">{c.title}</div>
                </td>
                <td className="py-3 pr-3 font-serif">{c.storyOfThesis || "—"}</td>
                <td className="py-3 pr-3 font-mono text-xs">{formatSyntax(c.syntax) || "—"}</td>
                <td className="py-3">{c.grandAdvice || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
        <div className="mt-8 overflow-x-auto">
          <p className="eyebrow mb-2">Matrix</p>
          <table className="w-full border text-sm">
            <thead>
              <tr><th className="border p-2" />{project.matrix.colLabels.map((l, i) => <th key={i} className="border p-2">{l}</th>)}</tr>
            </thead>
            <tbody>
              {project.matrix.cells.map((row, r) => (
                <tr key={r}>
                  <th className="border p-2 text-left">{project.matrix.rowLabels[r]}</th>
                  {row.map((c, i) => <td key={i} className="border p-2">{c || "—"}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
