import { describe, expect, it } from "vitest";
import { ARC_INFO, arcSequence, chaptersForPlan, matrixForPlan, PLANS } from "@/lib/book-config";

describe("SAY BOOK plan specifications", () => {
  it("uses the exact plan chapter counts, ARC allocations, matrices and wish limits", () => {
    expect(PLANS.basic).toMatchObject({ price: 59, chapters: 5, arc: { awareness: 1, resolution: 3, cta: 1 }, matrix: { rows: 3, cols: 3 }, revisedWishes: 1 });
    expect(PLANS.standard).toMatchObject({ price: 79, chapters: 7, arc: { awareness: 2, resolution: 3, cta: 2 }, matrix: { rows: 3, cols: 3 }, revisedWishes: 2 });
    expect(PLANS.founding).toMatchObject({ price: 199, chapters: 9, arc: { awareness: 3, resolution: 4, cta: 2 }, matrix: { rows: 4, cols: 3 }, revisedWishes: 3 });
  });

  it("builds exact ARC sequences and matrix dimensions", () => {
    expect(arcSequence("basic")).toEqual(["awareness", "resolution", "resolution", "resolution", "cta"]);
    expect(arcSequence("standard")).toEqual(["awareness", "awareness", "resolution", "resolution", "resolution", "cta", "cta"]);
    expect(arcSequence("founding")).toEqual(["awareness", "awareness", "awareness", "resolution", "resolution", "resolution", "resolution", "cta", "cta"]);
    expect(matrixForPlan("basic").cells).toHaveLength(3);
    expect(matrixForPlan("founding").cells).toHaveLength(4);
    expect(ARC_INFO.cta.name).toBe("Call to Action");
  });

  it("preserves chapter content by position when generating a larger plan", () => {
    const original = chaptersForPlan("basic", [], () => "new-id");
    original[0]!.title = "Retained chapter";
    const expanded = chaptersForPlan("standard", original, () => "new-id");
    expect(expanded).toHaveLength(7);
    expect(expanded[0]?.title).toBe("Retained chapter");
    expect(expanded[6]?.number).toBe(7);
  });
});
