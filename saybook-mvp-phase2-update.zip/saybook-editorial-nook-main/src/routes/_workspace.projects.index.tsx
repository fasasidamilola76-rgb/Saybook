import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/layout/PageHeader";
import { ProjectCard } from "@/components/book/ProjectCard";
import { useProjects } from "@/services/project-store";
import { EmptyProjects } from "./_workspace.dashboard";

export const Route = createFileRoute("/_workspace/projects/")({
  head: () => ({
    meta: [
      { title: "My Book Projects — SAY BOOK" },
      { name: "description", content: "All of your SAY BOOK projects." },
      { property: "og:title", content: "My Book Projects — SAY BOOK" },
      { property: "og:description", content: "All of your SAY BOOK projects." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Projects,
});

function Projects() {
  const projects = useProjects();
  return (
    <>
      <PageHeader
        eyebrow="Library"
        title="My Book Projects"
        description="Projects marked Sample are demonstration content."
        actions={<Button asChild><Link to="/projects/new">Create New Book</Link></Button>}
      />
      {projects.length === 0 ? <EmptyProjects /> : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => <ProjectCard key={p.id} project={p} />)}
        </div>
      )}
    </>
  );
}
