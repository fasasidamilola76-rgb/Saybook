import { createFileRoute, Link } from "@tanstack/react-router";
import { AuthCard } from "@/components/auth/AuthCard";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Sign up — SAY BOOK" },
      { name: "description", content: "Create a SAY BOOK account and start your book outline." },
      { property: "og:title", content: "Sign up — SAY BOOK" },
      { property: "og:description", content: "Create a SAY BOOK account and start your book outline." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AuthCard
      title="Create your account"
      subtitle="Start designing the architecture of your book."
      cta="Create account"
      fields={[
        { id: "name", label: "Full name", type: "text", autoComplete: "name" },
        { id: "email", label: "Email", type: "email", autoComplete: "email" },
        { id: "password", label: "Password", type: "password", autoComplete: "new-password" },
      ]}
      footer={<>Already have an account? <Link to="/login" className="font-medium text-primary hover:underline">Log in</Link></>}
    />
  ),
});
