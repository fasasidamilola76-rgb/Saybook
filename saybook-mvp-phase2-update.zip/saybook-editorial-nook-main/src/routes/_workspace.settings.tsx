import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_workspace/settings")({
  head: () => ({
    meta: [
      { title: "Account Settings — SAY BOOK" },
      { name: "description", content: "Manage your SAY BOOK account." },
      { property: "og:title", content: "Account Settings — SAY BOOK" },
      { property: "og:description", content: "Manage your SAY BOOK account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Settings,
});

function Settings() {
  const [saved, setSaved] = useState(false);
  return (
    <div className="max-w-2xl">
      <PageHeader eyebrow="Account" title="Account Settings" description="Preview only — no account changes are saved." />
      <form className="space-y-5" onChange={() => setSaved(false)} onSubmit={(e) => { e.preventDefault(); setSaved(true); }}>
        {[["name", "Full name", "text"], ["email", "Email", "email"], ["pen", "Default author name", "text"]].map(([id, label, type]) => (
          <div key={id} className="grid gap-1.5">
            <Label htmlFor={id}>{label}</Label>
            <Input id={id} name={id} type={type} required={id !== "pen"} />
          </div>
        ))}
        {saved && <p role="status" className="text-sm text-muted-foreground">Details checked for this preview. Account saving is not connected yet.</p>}
        <div className="flex justify-end"><Button type="submit">Save changes</Button></div>
      </form>
    </div>
  );
}
