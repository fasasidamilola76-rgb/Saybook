import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PageHeader } from "@/components/layout/PageHeader";
import { SampleBadge } from "@/components/book/badges";
import { ArcSection } from "@/components/dhm/ArcSection";
import { ChapterRow } from "@/components/dhm/ChapterRow";
import { SyntaxBuilder, SyntaxReference } from "@/components/dhm/SyntaxBuilder";
import { AdviceReview, ThesisReview } from "@/components/dhm/ReviewPanels";
import { DiagnosticsPanel } from "@/components/dhm/DiagnosticsPanel";
import { MatrixView } from "@/components/dhm/MatrixView";
import { ExportPanel } from "@/components/dhm/ExportPanel";
import { ARC_ORDER, PLANS, projectArcLabel } from "@/lib/book-config";
import { updateChapter, updateProject, useProject } from "@/services/project-store";

export const Route = createFileRoute("/_workspace/projects/$projectId/dhm")({
  head: () => ({
    meta: [
      { title: "DHM Workspace — SAY BOOK" },
      { name: "description", content: "Build and review your Double Helix Map." },
      { property: "og:title", content: "DHM Workspace — SAY BOOK" },
      { property: "og:description", content: "Build and review your Double Helix Map." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DhmWorkspace,
});

function DhmWorkspace() {
  const { projectId } = Route.useParams();
  const project = useProject(projectId);
  const [syntaxFor, setSyntaxFor] = useState<string | null>(null);
  if (!project) return <div className="space-y-4"><h1 className="text-2xl">Project not found</h1><p className="text-muted-foreground">This preview resets on reload.</p><Button asChild><Link to="/projects">My Book Projects</Link></Button></div>;
  const editing = project.chapters.find((c) => c.id === syntaxFor);
  const onChange = (id: string, patch: Parameters<typeof updateChapter>[2]) => updateChapter(project.id, id, "storyOfThesis" in patch ? { ...patch, thesisReview: "unreviewed" } : patch);

  return (
    <>
      <PageHeader
        eyebrow={`${PLANS[project.plan].name} · ARC ${projectArcLabel(project)}`}
        title={project.title || "Untitled book"}
        description={<span className="flex flex-wrap items-center gap-2">{project.isSample && <SampleBadge />}<span className="font-serif italic">{project.bookWish}</span></span>}
        actions={
          <>
            <Button asChild variant="outline"><Link to="/projects/$projectId/wish" params={{ projectId: project.id }}>Book Wish & plan</Link></Button>
            <Button onClick={() => updateProject(project.id, { status: project.status === "completed" ? "draft" : "completed" })}>
              {project.status === "completed" ? "Reopen as draft" : "Mark completed"}
            </Button>
          </>
        }
      />
      <Tabs defaultValue="map">
        <TabsList className="mb-6 h-auto flex-wrap">
          <TabsTrigger value="map">Map</TabsTrigger>
          <TabsTrigger value="syntax">SAY Syntax</TabsTrigger>
          <TabsTrigger value="thesis">Story of Thesis</TabsTrigger>
          <TabsTrigger value="advice">Grand Advice</TabsTrigger>
          <TabsTrigger value="diag">Diagnostics</TabsTrigger>
          <TabsTrigger value="matrix">Matrix</TabsTrigger>
          <TabsTrigger value="export">Export</TabsTrigger>
        </TabsList>
        <TabsContent value="map" className="space-y-8">
          <div className="hidden grid-cols-3 gap-3 px-4 lg:grid">
            <p className="eyebrow">Grand Narrative · Story of Thesis</p>
            <p className="eyebrow">Development · Chapter/String Syntax</p>
            <p className="eyebrow">Grand Advice · Main Advice</p>
          </div>
          {ARC_ORDER.map((stage) => {
            const chs = project.chapters.filter((c) => c.arc === stage);
            return (
              <ArcSection key={stage} stage={stage} count={chs.length}>
                {chs.map((c) => (
                  <ChapterRow key={c.id} chapter={c} onChange={(p) => onChange(c.id, p)} onEditSyntax={() => setSyntaxFor(c.id)} />
                ))}
              </ArcSection>
            );
          })}
        </TabsContent>
        <TabsContent value="syntax">
          <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
            <div className="space-y-3">
              {project.chapters.map((c) => (
                <div key={c.id} className="rounded-xl border bg-card p-4 shadow-card">
                  <p className="mb-3 font-semibold">Chapter {c.number} {c.title && `· ${c.title}`}</p>
                  <SyntaxBuilder value={c.syntax} onChange={(v) => onChange(c.id, { syntax: v })} />
                </div>
              ))}
            </div>
            <aside className="h-fit rounded-xl border bg-card p-5 shadow-card"><SyntaxReference /></aside>
          </div>
        </TabsContent>
        <TabsContent value="thesis"><ThesisReview chapters={project.chapters} onChange={onChange} /></TabsContent>
        <TabsContent value="advice"><AdviceReview chapters={project.chapters} onChange={onChange} /></TabsContent>
        <TabsContent value="diag"><DiagnosticsPanel project={project} /></TabsContent>
        <TabsContent value="matrix"><MatrixView matrix={project.matrix} onChange={(m) => updateProject(project.id, { matrix: m })} /></TabsContent>
        <TabsContent value="export"><ExportPanel project={project} /></TabsContent>
      </Tabs>
      <Dialog open={!!editing} onOpenChange={(o) => !o && setSyntaxFor(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>Chapter {editing?.number} syntax</DialogTitle></DialogHeader>
          {editing && <SyntaxBuilder value={editing.syntax} onChange={(v) => onChange(editing.id, { syntax: v })} />}
        </DialogContent>
      </Dialog>
    </>
  );
}
