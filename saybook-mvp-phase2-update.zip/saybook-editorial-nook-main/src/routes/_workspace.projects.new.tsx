import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/PageHeader";
import { BookProjectForm } from "@/components/book/BookProjectForm";
import { createProject } from "@/services/project-store";

export const Route = createFileRoute("/_workspace/projects/new")({
  head: () => ({
    meta: [
      { title: "Create New Book — SAY BOOK" },
      { name: "description", content: "Start a new book project from your Book Wish." },
      { property: "og:title", content: "Create New Book — SAY BOOK" },
      { property: "og:description", content: "Start a new book project from your Book Wish." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NewProject,
});

function NewProject() {
  const navigate = useNavigate();
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader eyebrow="New book" title="Create a book project" description="Describe your book and its reader. You can refine everything later." />
      <BookProjectForm
        onSaveDraft={(v) => {
          createProject(v);
          toast.success("Draft saved in this preview");
          navigate({ to: "/projects" });
        }}
        onContinue={(v) => {
          const p = createProject(v);
          navigate({ to: "/projects/$projectId/wish", params: { projectId: p.id } });
        }}
      />
    </div>
  );
}
