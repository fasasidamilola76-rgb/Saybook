import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteFooter, SiteHeader } from "@/components/layout/SiteChrome";
import { HelixPreview } from "@/components/book/HelixPreview";
import { ArcStageCard } from "@/components/dhm/ArcSection";
import { SyntaxReference } from "@/components/dhm/SyntaxBuilder";
import { PlanCard } from "@/components/book/PlanCard";
import { ARC_ORDER, PLAN_ORDER } from "@/lib/book-config";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SAY BOOK — Design the architecture of your book" },
      { name: "description", content: "Structure your non-fiction book with the Double Helix Map: Story of Thesis, SAY Development, and Grand Advice in one blueprint." },
      { property: "og:title", content: "SAY BOOK — Design the architecture of your book" },
      { property: "og:description", content: "Structure your non-fiction book with the Double Helix Map before you write it." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const STRANDS = [
  { name: "Grand Narrative", sub: "Story of Thesis", text: "One sentence per chapter. Read in order, they form the book's continuous argument." },
  { name: "Development", sub: "Chapter / String Syntax", text: "Each chapter is built from SAY points — sequences of Story, Yielded Evidence and Advice." },
  { name: "Grand Advice", sub: "Main Advice Statements", text: "The core instruction of each chapter, building the reader's path to action." },
];

const STEPS = ["Define your Book Wish.", "Select your book structure.", "Build your Double Helix Map.", "Review your book architecture.", "Export your outline."];

function Landing() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main>
        <section className="paper-grid border-b">
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:py-24">
            <div>
              <p className="eyebrow mb-4">Non-fiction book architecture</p>
              <h1 className="text-4xl font-semibold leading-[1.08] sm:text-5xl lg:text-6xl">
                Design the Architecture of Your Book Before You Write It.
              </h1>
              <p className="mt-6 max-w-xl text-lg text-muted-foreground">
                SAY BOOK helps you structure your non-fiction book through the Double Helix Map — connecting your Story of Thesis, SAY Development, and Grand Advice into one coherent book blueprint.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button asChild size="lg"><Link to="/signup">Create Your Book Outline</Link></Button>
                <Button asChild size="lg" variant="outline"><Link to="/how-dhm-works">Explore the DHM</Link></Button>
              </div>
            </div>
            <HelixPreview />
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
          <div className="grid gap-10 lg:grid-cols-[1fr_2fr]">
            <div>
              <p className="eyebrow mb-3">What SAY BOOK does</p>
              <h2 className="text-3xl font-semibold">A blueprint, not a ghostwriter.</h2>
            </div>
            <p className="text-lg leading-relaxed text-muted-foreground">
              SAY BOOK is a planning workspace for authors, consultants and educators. Starting from your Book Wish, it guides you through the ARC framework and SAY writing structures so every chapter has a clear place in the argument — before a single page of manuscript is written.
            </p>
          </div>
        </section>

        <section className="border-y bg-surface">
          <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
            <p className="eyebrow mb-3">The Double Helix Map</p>
            <h2 className="max-w-2xl text-3xl font-semibold">Three strands that run through every chapter.</h2>
            <div className="mt-10 grid gap-4 md:grid-cols-3">
              {STRANDS.map((s, i) => (
                <div key={s.name} className="rounded-xl border bg-card p-6 shadow-card">
                  <span className="font-serif text-sm text-muted-foreground">0{i + 1}</span>
                  <h3 className="mt-2 text-xl font-semibold">{s.name}</h3>
                  <p className="text-sm font-medium text-primary">{s.sub}</p>
                  <p className="mt-3 text-muted-foreground">{s.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
          <p className="eyebrow mb-3">The ARC framework</p>
          <h2 className="max-w-2xl text-3xl font-semibold">Every chapter belongs to a stage of the reader's journey.</h2>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {ARC_ORDER.map((s) => <ArcStageCard key={s} stage={s} />)}
          </div>
        </section>

        <section className="border-y bg-surface">
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-20 sm:px-6 lg:grid-cols-2">
            <div>
              <p className="eyebrow mb-3">SAY syntax</p>
              <h2 className="text-3xl font-semibold">Chapters built from Story, Yielded Evidence and Advice.</h2>
              <p className="mt-4 text-muted-foreground">Arrange the three units into short patterns. String patterns together and you have the development structure of a chapter.</p>
            </div>
            <div className="rounded-xl border bg-card p-6 shadow-card"><SyntaxReference /></div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
          <p className="eyebrow mb-3">The process</p>
          <h2 className="text-3xl font-semibold">Five steps from idea to outline.</h2>
          <ol className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {STEPS.map((s, i) => (
              <li key={s} className="rounded-xl border bg-card p-5 shadow-card">
                <span className="font-serif text-3xl font-semibold text-primary">{i + 1}</span>
                <p className="mt-3 font-medium">{s}</p>
              </li>
            ))}
          </ol>
        </section>

        <section className="border-t bg-surface">
          <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
            <p className="eyebrow mb-3">Book structures</p>
            <h2 className="text-3xl font-semibold">Choose the scale of your book.</h2>
            <div className="mt-10 grid gap-4 md:grid-cols-3">
              {PLAN_ORDER.map((p) => <PlanCard key={p} plan={p} />)}
            </div>
          </div>
        </section>

        <section className="bg-ink text-ink-foreground">
          <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-4 py-16 sm:px-6 md:flex-row md:items-center md:justify-between">
            <h2 className="max-w-xl text-3xl font-semibold">Start with your Book Wish.</h2>
            <Button asChild size="lg" variant="secondary"><Link to="/signup">Create Your Book Outline</Link></Button>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
