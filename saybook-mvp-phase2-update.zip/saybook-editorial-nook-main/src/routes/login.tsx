import { createFileRoute, Link } from "@tanstack/react-router";
import { AuthCard } from "@/components/auth/AuthCard";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log in — SAY BOOK" },
      { name: "description", content: "Log in to your SAY BOOK workspace." },
      { property: "og:title", content: "Log in — SAY BOOK" },
      { property: "og:description", content: "Log in to your SAY BOOK workspace." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AuthCard
      title="Welcome back"
      subtitle="Log in to continue planning your book."
      cta="Log in"
      fields={[
        { id: "email", label: "Email", type: "email", autoComplete: "email" },
        { id: "password", label: "Password", type: "password", autoComplete: "current-password" },
      ]}
      footer={<>New to SAY BOOK? <Link to="/signup" className="font-medium text-primary hover:underline">Create an account</Link></>}
    />
  ),
});
