import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/layout/PageHeader";
import { PlanCard } from "@/components/book/PlanCard";
import { ArcStructureEditor } from "@/components/book/ArcStructureEditor";
import { BookProjectForm } from "@/components/book/BookProjectForm";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PLAN_ORDER } from "@/lib/book-config";
import { planChangeWouldDiscardContent, setProjectPlan, updateProject, useProject } from "@/services/project-store";

export const Route = createFileRoute("/_workspace/projects/$projectId/wish")({
  head: () => ({
    meta: [
      { title: "Book Wish Setup — SAY BOOK" },
      { name: "description", content: "Refine your Book Wish and choose your book structure." },
      { property: "og:title", content: "Book Wish Setup — SAY BOOK" },
      { property: "og:description", content: "Refine your Book Wish and choose your book structure." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WishSetup,
});

function WishSetup() {
  const { projectId } = Route.useParams();
  const project = useProject(projectId);
  const [editDetails, setEditDetails] = useState(false);
  if (!project) return <div className="space-y-4"><h1 className="text-2xl">Project not found</h1><p className="text-muted-foreground">This preview resets on reload.</p><Button asChild><Link to="/projects">My Book Projects</Link></Button></div>;
  return (
    <div className="space-y-10">
      <PageHeader eyebrow={project.title} title="Book Wish Setup" description="Refine your central idea, then select the structure of your book." actions={<Button variant="outline" onClick={() => setEditDetails(true)}>Edit book details</Button>} />
      <section className="space-y-4 border-b pb-6">
        <div className="grid gap-1.5">
          <Label htmlFor="wish">Book Wish</Label>
          <Textarea id="wish" value={project.bookWish} onChange={(e) => updateProject(project.id, { bookWish: e.target.value })} />
        </div>
        {project.revisedWishes.map((w, i) => (
          <div key={i} className="grid gap-1.5">
            <Label htmlFor={`rw${i}`}>Revised Wish {i + 1}</Label>
            <Textarea
              id={`rw${i}`}
              value={w}
              placeholder="A sharper version of your Book Wish…"
              onChange={(e) => updateProject(project.id, { revisedWishes: project.revisedWishes.map((x, j) => (j === i ? e.target.value : x)) })}
            />
          </div>
        ))}
      </section>
      <section>
        <h2 className="mb-1 text-xl font-semibold">Book structure</h2>
        <p className="mb-4 text-sm text-muted-foreground">Plan specifications only — no payment is taken in this preview.</p>
        <div className="grid gap-4 md:grid-cols-3">
          {PLAN_ORDER.map((p) => (
            <PlanCard key={p} plan={p} selected={project.plan === p} onSelect={() => {
              const destructive = planChangeWouldDiscardContent(project.id, p);
              const message = destructive
                ? "This plan has fewer chapters, revised wishes, or matrix cells. Content outside the new plan limits will be removed. Continue only if you have exported or copied anything you want to keep."
                : "Change this project's book plan? Existing chapter content will be retained where possible.";
              if (window.confirm(message)) {
                setProjectPlan(project.id, p);
                toast.success(`Book plan changed to ${p === "founding" ? "Founding Member" : p[0].toUpperCase() + p.slice(1)}`);
              }
            }} />
          ))}
        </div>
        {project.plan === "founding" && <ArcStructureEditor key={project.id + project.plan} project={project} />}
      </section>
      <div className="flex justify-end">
        <Button asChild><Link to="/projects/$projectId/dhm" params={{ projectId: project.id }}>Open DHM Workspace</Link></Button>
      </div>
      <Dialog open={editDetails} onOpenChange={setEditDetails}>
        <DialogContent className="max-h-[85vh] max-w-3xl overflow-y-auto">
          <DialogHeader><DialogTitle>Edit book details</DialogTitle></DialogHeader>
          <BookProjectForm editing initialValues={project} onSaveDraft={() => {}} onContinue={(values) => { updateProject(project.id, values); setEditDetails(false); toast.success("Book details updated in this preview"); }} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
