import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { HelixPreview } from "@/components/book/HelixPreview";
import { ArcStageCard } from "@/components/dhm/ArcSection";
import { SyntaxReference } from "@/components/dhm/SyntaxBuilder";
import { ARC_ORDER } from "@/lib/book-config";

export const Route = createFileRoute("/_workspace/how-dhm-works")({
  head: () => ({
    meta: [
      { title: "How the DHM Works — SAY BOOK" },
      { name: "description", content: "Learn the Double Helix Map, the ARC framework and SAY syntax." },
      { property: "og:title", content: "How the DHM Works — SAY BOOK" },
      { property: "og:description", content: "Learn the Double Helix Map, the ARC framework and SAY syntax." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <div className="space-y-12">
      <PageHeader eyebrow="Guide" title="How the Double Helix Map works" description="Three strands — Story of Thesis, Development and Grand Advice — run through every chapter, grouped by ARC stage." />
      <HelixPreview />
      <section>
        <h2 className="mb-4 text-2xl font-semibold">The ARC framework</h2>
        <div className="grid gap-4 md:grid-cols-3">{ARC_ORDER.map((s) => <ArcStageCard key={s} stage={s} />)}</div>
      </section>
      <section className="rounded-xl border bg-card p-6 shadow-card">
        <h2 className="mb-4 text-2xl font-semibold">SAY syntax</h2>
        <SyntaxReference />
      </section>
    </div>
  ),
});
