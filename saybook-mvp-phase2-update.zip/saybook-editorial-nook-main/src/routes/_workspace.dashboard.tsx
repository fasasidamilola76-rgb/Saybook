import { createFileRoute, Link } from "@tanstack/react-router";
import { BookPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/layout/PageHeader";
import { ProjectCard } from "@/components/book/ProjectCard";
import { StatusBadge } from "@/components/book/badges";
import { formatDate } from "@/lib/book-config";
import { useProjects } from "@/services/project-store";

export const Route = createFileRoute("/_workspace/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — SAY BOOK" },
      { name: "description", content: "Your SAY BOOK projects at a glance." },
      { property: "og:title", content: "Dashboard — SAY BOOK" },
      { property: "og:description", content: "Your SAY BOOK projects at a glance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

export function EmptyProjects() {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed bg-card px-6 py-16 text-center">
      <BookPlus className="h-10 w-10 text-primary" />
      <p className="mt-4 max-w-md font-serif text-xl">You haven't created a book project yet. Start by defining your Book Wish.</p>
      <Button asChild className="mt-6"><Link to="/projects/new">Create Your First Book</Link></Button>
    </div>
  );
}

function Dashboard() {
  const projects = useProjects();
  const recent = [...projects].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, 4);
  return (
    <>
      <PageHeader
        eyebrow="Dashboard"
        title="Welcome back."
        description="Pick up where you left off, or begin a new book from its Book Wish."
        actions={<Button asChild><Link to="/projects/new">Create New Book</Link></Button>}
      />
      {projects.length === 0 ? (
        <EmptyProjects />
      ) : (
        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <section>
            <h2 className="mb-4 text-xl font-semibold">Saved book projects</h2>
            <div className="grid gap-4 md:grid-cols-2">
              {projects.map((p) => <ProjectCard key={p.id} project={p} />)}
            </div>
          </section>
          <section>
            <h2 className="mb-4 text-xl font-semibold">Recently edited</h2>
            <ul className="divide-y rounded-xl border bg-card shadow-card">
              {recent.map((p) => (
                <li key={p.id}>
                  <Link to="/projects/$projectId/dhm" params={{ projectId: p.id }} className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-muted">
                    <div className="min-w-0">
                      <p className="truncate font-medium">{p.title || "Untitled book"}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(p.updatedAt)}</p>
                    </div>
                    <StatusBadge status={p.status} />
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        </div>
      )}
    </>
  );
}
