/** Core domain types for SAY BOOK. Backend models should mirror these shapes. */

export type PlanId = "basic" | "standard" | "founding";
export type ArcStage = "awareness" | "resolution" | "cta";
export type SayUnit = "S" | "Y" | "A";
/** One SAY point, e.g. ["S","Y","A"] = Story → Yielded Evidence → Advice. */
export type SayPoint = SayUnit[];
export type ProjectStatus = "draft" | "completed";
export type ReviewStatus = "unreviewed" | "reviewed";

export interface Chapter {
  id: string;
  number: number;
  title: string;
  arc: ArcStage;
  storyOfThesis: string;
  syntax: SayPoint[];
  development: string;
  grandAdvice: string;
  notes: string;
  complete: boolean;
  thesisReview: ReviewStatus;
}

export interface Matrix {
  rowLabels: string[];
  colLabels: string[];
  cells: string[][];
}

export interface BookProject {
  id: string;
  title: string;
  author: string;
  topic: string;
  audience: string;
  problem: string;
  transformation: string;
  bookWish: string;
  revisedWishes: string[];
  context: string;
  plan: PlanId;
  /** Optional author-defined chapter order for the Founding structure. */
  customArc?: ArcStage[];
  status: ProjectStatus;
  createdAt: string;
  updatedAt: string;
  chapters: Chapter[];
  matrix: Matrix;
  /** True for frontend demonstration data. */
  isSample?: boolean;
}

export type BookProjectInput = Pick<
  BookProject,
  "title" | "author" | "topic" | "audience" | "problem" | "transformation" | "bookWish" | "context"
>;
