import type { ArcStage, Chapter, Matrix, PlanId, SayUnit } from "@/types/book";

export interface PlanSpec {
  id: PlanId;
  name: string;
  price: number;
  chapters: number;
  arc: Record<ArcStage, number>;
  arcLabel: string;
  matrix: { rows: number; cols: number };
  revisedWishes: number;
  extras: string[];
}

export const PLANS: Record<PlanId, PlanSpec> = {
  basic: {
    id: "basic",
    name: "Basic",
    price: 59,
    chapters: 5,
    arc: { awareness: 1, resolution: 3, cta: 1 },
    arcLabel: "1-3-1",
    matrix: { rows: 3, cols: 3 },
    revisedWishes: 1,
    extras: [],
  },
  standard: {
    id: "standard",
    name: "Standard",
    price: 79,
    chapters: 7,
    arc: { awareness: 2, resolution: 3, cta: 2 },
    arcLabel: "2-3-2",
    matrix: { rows: 3, cols: 3 },
    revisedWishes: 2,
    extras: [],
  },
  founding: {
    id: "founding",
    name: "Founding Member",
    price: 199,
    chapters: 9,
    arc: { awareness: 3, resolution: 4, cta: 2 },
    arcLabel: "3-4-2",
    matrix: { rows: 4, cols: 3 },
    revisedWishes: 3,
    extras: ["Customizable ARC structure", "Limited to 50 founders"],
  },
};

export const PLAN_ORDER: PlanId[] = ["basic", "standard", "founding"];

export const ARC_ORDER: ArcStage[] = ["awareness", "resolution", "cta"];

export const ARC_INFO: Record<ArcStage, { letter: string; name: string; focus: string }> = {
  awareness: {
    letter: "A",
    name: "Awareness",
    focus: "Focuses on the external or contextual problem.",
  },
  resolution: {
    letter: "R",
    name: "Resolution",
    focus: "Focuses on the methodological or systemic solution.",
  },
  cta: {
    letter: "C",
    name: "Call to Action",
    focus: "Focuses on the identity or essential shift and practical execution.",
  },
};

export const SAY_INFO: Record<SayUnit, string> = {
  S: "Story",
  Y: "Yielded Evidence",
  A: "Advice",
};

export const SAY_MODULE_NOTE =
  "Each SAY point is designed to become a 200–300 word module when developed.";

export function arcSequence(plan: PlanId): ArcStage[] {
  const { arc } = PLANS[plan];
  return ARC_ORDER.flatMap((stage) => Array<ArcStage>(arc[stage]).fill(stage));
}

export function projectArcSequence(project: { plan: PlanId; customArc?: ArcStage[] }): ArcStage[] {
  return project.plan === "founding" && project.customArc?.length === PLANS.founding.chapters
    ? project.customArc
    : arcSequence(project.plan);
}

export function projectArcLabel(project: { plan: PlanId; customArc?: ArcStage[] }): string {
  const sequence = projectArcSequence(project);
  return ARC_ORDER.map((stage) => sequence.filter((value) => value === stage).length).join("-");
}

export function emptyChapter(number: number, arc: ArcStage, id: string): Chapter {
  return {
    id,
    number,
    title: "",
    arc,
    storyOfThesis: "",
    syntax: [],
    development: "",
    grandAdvice: "",
    notes: "",
    complete: false,
    thesisReview: "unreviewed",
  };
}

/** Rebuild chapters for a plan, keeping existing chapter content by position. */
export function chaptersForPlan(plan: PlanId, existing: Chapter[], makeId: () => string): Chapter[] {
  return arcSequence(plan).map((arc, i) => {
    const prev = existing[i];
    return prev ? { ...prev, number: i + 1, arc } : emptyChapter(i + 1, arc, makeId());
  });
}

export function matrixForPlan(plan: PlanId, existing?: Matrix): Matrix {
  const { rows, cols } = PLANS[plan].matrix;
  return {
    rowLabels: Array.from({ length: rows }, (_, r) => existing?.rowLabels[r] ?? `Row ${r + 1}`),
    colLabels: Array.from({ length: cols }, (_, c) => existing?.colLabels[c] ?? `Column ${c + 1}`),
    cells: Array.from({ length: rows }, (_, r) =>
      Array.from({ length: cols }, (_, c) => existing?.cells[r]?.[c] ?? ""),
    ),
  };
}

export function formatSyntax(syntax: Chapter["syntax"]): string {
  return syntax.map((p) => p.join("")).join(" + ");
}

export function isChapterFilled(ch: Chapter): boolean {
  return Boolean(ch.title.trim() && ch.storyOfThesis.trim() && ch.syntax.length && ch.grandAdvice.trim());
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  });
}
