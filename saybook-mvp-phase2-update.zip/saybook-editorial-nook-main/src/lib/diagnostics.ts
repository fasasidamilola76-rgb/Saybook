import type { BookProject } from "@/types/book";
import { ARC_INFO, projectArcSequence, formatSyntax, isChapterFilled } from "@/lib/book-config";

export type DiagnosticStatus = "complete" | "attention" | "incomplete";
export type DiagnosticKind = "automated" | "review";

export interface DiagnosticResult {
  id: string;
  title: string;
  kind: DiagnosticKind;
  status: DiagnosticStatus;
  summary: string;
  details: string[];
}

/**
 * Frontend-only structural checks. These count and compare fields;
 * they do not judge meaning. Items marked "review" need a human reader.
 */
export function runDiagnostics(p: BookProject): DiagnosticResult[] {
  const chs = p.chapters;
  const label = (n: number) => `Chapter ${n}`;

  const gaps = chs.flatMap((c) => {
    const missing: string[] = [];
    if (!c.storyOfThesis.trim()) missing.push("Story of Thesis");
    if (!c.syntax.length) missing.push("Development syntax");
    if (!c.grandAdvice.trim()) missing.push("Grand Advice");
    return missing.length ? [`${label(c.number)}: missing ${missing.join(", ")}`] : [];
  });

  const invalidSyntax = chs.flatMap((c) => {
    const issues = c.syntax.flatMap((point, index) => {
      if (!point.length) return [`${label(c.number)} · Point ${index + 1} is empty.`];
      const invalidUnits = point.filter((unit) => !["S", "Y", "A"].includes(unit));
      return invalidUnits.length ? [`${label(c.number)} · Point ${index + 1} contains an unsupported SAY unit.`] : [];
    });
    return issues;
  });
  const patterns = chs.filter((c) => c.syntax.length).map((c) => formatSyntax(c.syntax));
  const unique = new Set(patterns);
  const repeated = patterns.filter((s, i) => patterns.indexOf(s) !== i);

  const expected = projectArcSequence(p);
  const misaligned = chs.filter((c, i) => c.arc !== expected[i]);

  const sotMissing = chs.filter((c) => !c.storyOfThesis.trim());
  const gaMissing = chs.filter((c) => !c.grandAdvice.trim());
  const filled = chs.filter(isChapterFilled).length;
  const emptyMatrixCells = p.matrix.cells.flatMap((row, r) => row.flatMap((cell, c) => cell.trim() ? [] : [`Row ${r + 1}, column ${c + 1} is empty.`]));
  const expectedCounts = expected.reduce<Record<string, number>>((counts, stage) => ({ ...counts, [stage]: (counts[stage] ?? 0) + 1 }), {});
  const actualCounts = chs.reduce<Record<string, number>>((counts, chapter) => ({ ...counts, [chapter.arc]: (counts[chapter.arc] ?? 0) + 1 }), {});
  const allocationMismatch = ["awareness", "resolution", "cta"].some((stage) => (expectedCounts[stage] ?? 0) !== (actualCounts[stage] ?? 0));

  const status = (bad: number, total: number): DiagnosticStatus =>
    bad === 0 ? "complete" : bad >= total ? "incomplete" : "attention";

  return [
    {
      id: "gaps",
      title: "Gaps in the Helix",
      kind: "automated",
      status: status(gaps.length, chs.length),
      summary: gaps.length ? `${gaps.length} chapter(s) have empty strands.` : "Every chapter has all three strands.",
      details: gaps,
    },
    {
      id: "syntax",
      title: "Syntax Variety",
      kind: "automated",
      status: patterns.length === 0 || invalidSyntax.length ? "incomplete" : repeated.length ? "attention" : "complete",
      summary: patterns.length
        ? `${unique.size} distinct syntax pattern(s) across ${patterns.length} chapter(s).`
        : "No syntax has been arranged yet.",
      details: [...(repeated.length ? [`Repeated pattern(s): ${[...new Set(repeated)].join("; ")}`] : []), ...invalidSyntax],
    },
    {
      id: "arc",
      title: "ARC Alignment",
      kind: "automated",
      status: misaligned.length || allocationMismatch ? "attention" : "complete",
      summary: misaligned.length
        ? `${misaligned.length} chapter(s) differ from the plan's ARC order.`
        : "Chapter stages match the selected ARC structure.",
      details: [...misaligned.map((c) => `${label(c.number)} is ${ARC_INFO[c.arc].name}; plan expects ${ARC_INFO[expected[c.number - 1] ?? c.arc].name}.`), ...(allocationMismatch ? ["The overall Awareness–Resolution–Call to Action allocation differs from the selected plan."] : [])],
    },
    {
      id: "sot",
      title: "Story of Thesis Continuity",
      kind: "review",
      status: status(sotMissing.length, chs.length),
      summary: sotMissing.length
        ? `${sotMissing.length} thesis sentence(s) missing. Read the review panel to judge flow.`
        : "All sentences present. Read them in sequence to judge whether the argument flows.",
      details: sotMissing.map((c) => `${label(c.number)} has no thesis sentence.`),
    },
    {
      id: "ga",
      title: "Grand Advice Continuity",
      kind: "review",
      status: status(gaMissing.length, chs.length),
      summary: gaMissing.length
        ? `${gaMissing.length} advice statement(s) missing.`
        : "All statements present. Review whether the instruction builds chapter to chapter.",
      details: gaMissing.map((c) => `${label(c.number)} has no Grand Advice.`),
    },
    {
      id: "complete",
      title: "Chapter Completeness",
      kind: "automated",
      status: status(chs.length - filled, chs.length),
      summary: `${filled} of ${chs.length} chapters have a title and all three strands.`,
      details: [],
    },
    {
      id: "matrix",
      title: "Matrix Coverage",
      kind: "automated",
      status: emptyMatrixCells.length ? (emptyMatrixCells.length === p.matrix.cells.reduce((n, row) => n + row.length, 0) ? "incomplete" : "attention") : "complete",
      summary: emptyMatrixCells.length ? `${emptyMatrixCells.length} of ${p.matrix.cells.reduce((n, row) => n + row.length, 0)} matrix cells are empty. Empty cells are a prompt to review, not necessarily an error.` : "Every matrix cell contains content.",
      details: emptyMatrixCells,
    },
  ];
}
