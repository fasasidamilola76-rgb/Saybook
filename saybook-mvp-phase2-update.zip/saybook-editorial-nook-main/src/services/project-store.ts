/**
 * Project service — FRONTEND PLACEHOLDER.
 * Data lives in memory for this phase and resets on reload.
 * Replace the function bodies with backend calls; keep the signatures.
 */
import { useSyncExternalStore } from "react";
import type { ArcStage, BookProject, BookProjectInput, Chapter, PlanId } from "@/types/book";
import { SAMPLE_PROJECTS } from "@/data/sample-projects";
import { ARC_ORDER, chaptersForPlan, matrixForPlan, PLANS } from "@/lib/book-config";

let projects: BookProject[] = SAMPLE_PROJECTS;
const listeners = new Set<() => void>();

const emit = () => listeners.forEach((l) => l());
const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => listeners.delete(l);
};
const now = () => new Date().toISOString();
const makeId = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : Math.random().toString(36).slice(2);

export function listProjects(): BookProject[] {
  return projects;
}

export function getProject(id: string): BookProject | undefined {
  return projects.find((p) => p.id === id);
}

export function createProject(input: BookProjectInput, plan: PlanId = "basic"): BookProject {
  const ts = now();
  const project: BookProject = {
    ...input,
    id: makeId(),
    plan,
    status: "draft",
    createdAt: ts,
    updatedAt: ts,
    revisedWishes: Array(PLANS[plan].revisedWishes).fill(""),
    chapters: chaptersForPlan(plan, [], makeId),
    matrix: matrixForPlan(plan),
  };
  projects = [project, ...projects];
  emit();
  return project;
}

export function updateProject(id: string, patch: Partial<BookProject>) {
  projects = projects.map((p) => (p.id === id ? { ...p, ...patch, updatedAt: now() } : p));
  emit();
}

export function planChangeWouldDiscardContent(id: string, plan: PlanId): boolean {
  const p = getProject(id);
  if (!p || p.plan === plan) return false;
  const chapterLimit = PLANS[plan].chapters;
  const wishLimit = PLANS[plan].revisedWishes;
  const { rows, cols } = PLANS[plan].matrix;
  const removedChapters = p.chapters.slice(chapterLimit).some((c) =>
    Boolean(c.title.trim() || c.storyOfThesis.trim() || c.development.trim() || c.grandAdvice.trim() || c.notes.trim() || c.syntax.length),
  );
  const removedWishes = p.revisedWishes.slice(wishLimit).some((wish) => Boolean(wish.trim()));
  const removedMatrix = p.matrix.cells.some((row, r) => row.some((cell, c) => Boolean(cell.trim()) && (r >= rows || c >= cols)));
  return removedChapters || removedWishes || removedMatrix;
}

export function setProjectPlan(id: string, plan: PlanId) {
  const p = getProject(id);
  if (!p || p.plan === plan) return;
  const wishes = Array.from({ length: PLANS[plan].revisedWishes }, (_, i) => p.revisedWishes[i] ?? "");
  updateProject(id, {
    plan,
    customArc: [],
    revisedWishes: wishes,
    chapters: chaptersForPlan(plan, p.chapters, makeId),
    matrix: matrixForPlan(plan, p.matrix),
  });
}

export function setProjectArc(id: string, sequence: ArcStage[]): boolean {
  const project = getProject(id);
  if (!project || project.plan !== "founding" || sequence.length !== PLANS.founding.chapters || sequence.some((stage) => !ARC_ORDER.includes(stage))) return false;
  updateProject(id, {
    customArc: [...sequence],
    chapters: project.chapters.map((chapter, index) => ({ ...chapter, arc: sequence[index] ?? chapter.arc })),
  });
  return true;
}

export function updateChapter(projectId: string, chapterId: string, patch: Partial<Chapter>) {
  const p = getProject(projectId);
  if (!p) return;
  updateProject(projectId, {
    chapters: p.chapters.map((c) => (c.id === chapterId ? { ...c, ...patch } : c)),
  });
}

export function deleteProject(id: string) {
  projects = projects.filter((p) => p.id !== id);
  emit();
}

export function useProjects(): BookProject[] {
  return useSyncExternalStore(subscribe, listProjects, listProjects);
}

export function useProject(id: string): BookProject | undefined {
  const all = useProjects();
  return all.find((p) => p.id === id);
}
