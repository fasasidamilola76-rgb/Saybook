import type { BookProject } from "@/types/book";
import { ARC_INFO, formatSyntax, projectArcLabel } from "@/lib/book-config";

export type ExportResult = { ok: true; method: "browser-print" } | { ok: false; reason: string };

const escapeHtml = (value: string) => value
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#39;")
  .replaceAll("\n", "<br>");

const text = (value: string | undefined) => escapeHtml(value?.trim() || "—");

/** Opens a print-ready, user-data-only document. In the print dialog choose “Save as PDF”. */
export function exportDhmPdf(project: BookProject): ExportResult {
  if (typeof window === "undefined") return { ok: false, reason: "PDF export is only available in a browser." };
  const printWindow = window.open("", "_blank", "width=1000,height=800");
  if (!printWindow) return { ok: false, reason: "The export window was blocked. Allow pop-ups for SAY BOOK and try again." };

  const chapters = project.chapters.map((chapter) => `
    <section class="chapter">
      <div class="chapter-kicker">CHAPTER ${chapter.number} · ${escapeHtml(ARC_INFO[chapter.arc].name.toUpperCase())}</div>
      <h2>${text(chapter.title)}</h2>
      <div class="strands">
        <article><h3>Grand Narrative · Story of Thesis</h3><p>${text(chapter.storyOfThesis)}</p></article>
        <article><h3>Development · Chapter/String Syntax</h3><p class="syntax">${text(formatSyntax(chapter.syntax))}</p><p>${text(chapter.development)}</p></article>
        <article><h3>Grand Advice · Main Advice</h3><p>${text(chapter.grandAdvice)}</p></article>
      </div>
      ${chapter.notes.trim() ? `<p class="notes"><strong>Notes:</strong> ${text(chapter.notes)}</p>` : ""}
    </section>`).join("");

  const matrix = `<table><thead><tr><th></th>${project.matrix.colLabels.map((label) => `<th>${text(label)}</th>`).join("")}</tr></thead><tbody>${project.matrix.cells.map((row, r) => `<tr><th>${text(project.matrix.rowLabels[r])}</th>${row.map((cell) => `<td>${text(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
  const revisedWishes = project.revisedWishes.map((wish, i) => `<p><strong>Revised Wish ${i + 1}:</strong> ${text(wish)}</p>`).join("");

  printWindow.document.open();
  printWindow.document.write(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${text(project.title)} — SAY BOOK Architecture</title>
  <style>
    @page{size:A4;margin:18mm}*{box-sizing:border-box}body{font:11pt/1.55 Georgia,serif;color:#252525;margin:0}h1,h2,h3,p{margin-top:0}h1{font-size:30pt;line-height:1.1;margin:8px 0}h2{font-size:19pt;margin:5px 0 12px}h3{font:700 9pt/1.3 Arial,sans-serif;letter-spacing:.04em;text-transform:uppercase;margin:0 0 6px;color:#5b554d}.brand,.eyebrow,.chapter-kicker{font:700 8pt Arial,sans-serif;letter-spacing:.15em;text-transform:uppercase;color:#71675c}.cover{padding:30mm 0 18mm;border-bottom:1px solid #bbb;min-height:210mm}.cover .wish{font-size:15pt;font-style:italic;max-width:620px;margin-top:24px}.meta{font:10pt Arial,sans-serif;color:#555;margin-top:24px}.section-title{font:700 16pt Arial,sans-serif;margin:22px 0 12px}.chapter{page-break-inside:avoid;border-top:1px solid #cfc9c0;padding:16px 0}.chapter-kicker{letter-spacing:.1em}.strands{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}.strands article{min-width:0}.strands p{margin:0;overflow-wrap:anywhere}.syntax{font:700 10pt monospace;margin-bottom:7px!important}.notes{font-size:9pt;color:#655;margin-top:10px}table{width:100%;border-collapse:collapse;font-size:9pt;page-break-inside:auto}th,td{border:1px solid #c9c4bc;padding:7px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#f3f0eb}.wish-list{margin:10px 0 24px}.footer{margin-top:30px;padding-top:10px;border-top:1px solid #ccc;font:8pt Arial,sans-serif;color:#777}@media(max-width:700px){.strands{grid-template-columns:1fr}}@media print{a{color:inherit;text-decoration:none}.chapter{break-inside:avoid}}
  </style></head><body>
  <header class="cover"><div class="brand">SAY BOOK · BOOK ARCHITECTURE</div><h1>${text(project.title || "Untitled book")}</h1><p class="meta">Author: ${text(project.author)}<br>Plan: ${escapeHtml(project.plan === "founding" ? "Founding Member" : project.plan[0].toUpperCase() + project.plan.slice(1))}<br>ARC: ${escapeHtml(projectArcLabel(project))}</p><h2 class="section-title">Initial Book Wish</h2><p class="wish">${text(project.bookWish)}</p><div class="wish-list">${revisedWishes}</div><p class="meta">Topic: ${text(project.topic)}<br>Audience: ${text(project.audience)}<br>Problem: ${text(project.problem)}<br>Transformation: ${text(project.transformation)}<br>Context: ${text(project.context)}</p></header>
  <main><h2 class="section-title">Double Helix Map</h2>${chapters}<section><h2 class="section-title">Book Matrix</h2>${matrix}</section></main><footer class="footer">SAY BOOK · Generated from the author's current project content · ${new Date().toLocaleDateString()}</footer>
  <script>window.addEventListener('load',function(){window.focus();window.print();});</script></body></html>`);
  printWindow.document.close();
  return { ok: true, method: "browser-print" };
}
