# Saybook Editorial Nook

Implement exactly the screenshot and nothing else

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://saybook-editorial-nook.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/8e7cb443-06b1-45a2-ad17-3cb2d4a8eecb).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## SAY BOOK MVP implementation notes

This repository is still a frontend-first Lovable project. The current project store is in-memory demo state; it is **not** an authenticated or durable database. Do not use it for production author content until the Supabase client and server-side data layer have been connected.

### Supabase foundation

1. Create a Supabase project.
2. Copy `.env.example` to `.env.local` and set `VITE_SUPABASE_URL` and the project's publishable/anon key.
3. Apply `supabase/migrations/202611020001_saybook_schema.sql` using the Supabase SQL Editor or Supabase CLI.
4. Implement the Supabase client and replace `src/services/project-store.ts` with authenticated database operations. Keep the owner-scoped RLS policies enabled.
5. Never put a Supabase service-role key or AI provider key in a `VITE_*` variable.

The migration establishes profiles, projects, wishes, chapters, matrix axes/cells, ARC configurations and diagnostics storage, with owner-scoped Row Level Security. Applying the migration alone does not connect the current frontend to the database.

### PDF export

The Export tab opens a print-ready document populated from the current project object. In the browser print dialog, select **Save as PDF**. This is a structured PDF export via the browser print engine, not a fillable PDF. Since project state is currently in memory, export before reloading the preview if you have edited a project.

### AI and account services

Authentication, durable project sync and genuine AI assistance are not active in this source snapshot. They require a configured Supabase project, server-side API endpoints and securely stored provider credentials. No fake AI responses are provided.
