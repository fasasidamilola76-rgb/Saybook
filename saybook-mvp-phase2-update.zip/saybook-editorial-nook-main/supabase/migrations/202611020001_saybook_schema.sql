-- SAY BOOK initial relational schema. Apply with Supabase CLI or SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null default '',
  author text not null default '',
  topic text not null default '',
  audience text not null default '',
  problem text not null default '',
  transformation text not null default '',
  context text not null default '',
  plan text not null default 'basic' check (plan in ('basic','standard','founding')),
  status text not null default 'draft' check (status in ('draft','completed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists projects_owner_updated_idx on public.projects(owner_id, updated_at desc);

create table if not exists public.book_wishes (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  wish_type text not null check (wish_type in ('original','revised')),
  revision_number integer not null default 0 check (revision_number >= 0),
  content text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(project_id, wish_type, revision_number),
  check ((wish_type = 'original' and revision_number = 0) or (wish_type = 'revised' and revision_number > 0))
);

create table if not exists public.chapters (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  chapter_number integer not null check (chapter_number > 0),
  title text not null default '',
  arc_stage text not null check (arc_stage in ('awareness','resolution','cta')),
  story_of_thesis text not null default '',
  say_syntax jsonb not null default '[]'::jsonb check (jsonb_typeof(say_syntax) = 'array'),
  development text not null default '',
  grand_advice text not null default '',
  notes text not null default '',
  complete boolean not null default false,
  thesis_review text not null default 'unreviewed' check (thesis_review in ('unreviewed','reviewed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(project_id, chapter_number)
);
create index if not exists chapters_project_number_idx on public.chapters(project_id, chapter_number);

create table if not exists public.matrix_axes (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  axis text not null check (axis in ('row','column')),
  position integer not null check (position >= 0),
  label text not null default '',
  unique(project_id, axis, position)
);
create table if not exists public.matrix_cells (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  row_position integer not null check (row_position >= 0),
  column_position integer not null check (column_position >= 0),
  content text not null default '',
  updated_at timestamptz not null default now(),
  unique(project_id, row_position, column_position)
);

create table if not exists public.arc_configurations (
  project_id uuid primary key references public.projects(id) on delete cascade,
  custom_sequence jsonb not null default '[]'::jsonb check (jsonb_typeof(custom_sequence) = 'array'),
  updated_at timestamptz not null default now()
);
create table if not exists public.diagnostics_results (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  result jsonb not null default '{}'::jsonb check (jsonb_typeof(result) = 'object'),
  created_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;

do $$
declare t text;
begin
  foreach t in array array['profiles','projects','book_wishes','chapters','matrix_cells','arc_configurations'] loop
    execute format('drop trigger if exists set_updated_at on public.%I', t);
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', ''))
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.book_wishes enable row level security;
alter table public.chapters enable row level security;
alter table public.matrix_axes enable row level security;
alter table public.matrix_cells enable row level security;
alter table public.arc_configurations enable row level security;
alter table public.diagnostics_results enable row level security;

create policy "profiles_select_own" on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));
create policy "projects_select_own" on public.projects for select to authenticated using (owner_id = (select auth.uid()));
create policy "projects_insert_own" on public.projects for insert to authenticated with check (owner_id = (select auth.uid()));
create policy "projects_update_own" on public.projects for update to authenticated using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));
create policy "projects_delete_own" on public.projects for delete to authenticated using (owner_id = (select auth.uid()));

do $$
declare t text;
begin
  foreach t in array array['book_wishes','chapters','matrix_axes','matrix_cells','arc_configurations','diagnostics_results'] loop
    execute format('create policy %I on public.%I for all to authenticated using (exists (select 1 from public.projects p where p.id = project_id and p.owner_id = (select auth.uid()))) with check (exists (select 1 from public.projects p where p.id = project_id and p.owner_id = (select auth.uid())))', t || '_owner_all', t);
  end loop;
end $$;
