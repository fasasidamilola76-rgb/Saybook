# SAY BOOK MVP roadmap

- [x] Inspect existing Lovable codebase and preserve its design.
- [x] Confirm exact Basic, Standard and Founding Member plan definitions.
- [x] Add confirmation before plan changes that may discard content.
- [x] Expand deterministic diagnostics to cover malformed SAY points and matrix coverage.
- [x] Add print-ready book architecture export; browser print dialog can save as PDF.
- [x] Add Supabase relational schema and owner-scoped RLS migration as an integration foundation.
- [ ] Configure Supabase project credentials and connect frontend authentication.
- [ ] Replace in-memory project store with authenticated database persistence.
- [ ] Implement server-side AI endpoints after provider credentials are configured.
- [ ] Add end-to-end tests for registration, ownership, persistence, plan transitions and export.
- [ ] Run production build, lint and full test suite in an environment with dependencies installed.

## Explicitly not complete

The Supabase migration is a schema foundation only; the current frontend is not yet connected to it. Authentication, durable persistence and AI features are not active. PDF export uses the browser's print-to-PDF workflow and is not a fillable PDF.
