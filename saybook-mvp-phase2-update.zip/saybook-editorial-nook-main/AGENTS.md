<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep domain types, plan rules, demo state services and reusable UI separate so Codex can replace services without rebuilding pages.
- Demo state stays in memory with no authentication or persistence claims; this phase intentionally has no backend.
- Store Founding ARC overrides on the project and derive labels, chapter grouping and diagnostics from that single sequence to keep them consistent.
